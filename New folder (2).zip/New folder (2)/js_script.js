// Minimal JS: nav toggle, active nav highlighting, and reveal-on-scroll
document.addEventListener('DOMContentLoaded', function () {
  // Year in footer
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Nav toggle for mobile
  const navToggle = document.getElementById('nav-toggle');
  const navList = document.getElementById('nav-list');
  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navList.classList.toggle('show');
    });

    // Close nav on link click (mobile)
    navList.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        if (navList.classList.contains('show')) {
          navList.classList.remove('show');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  // Scroll reveal using IntersectionObserver
  const revealEls = document.querySelectorAll('.section, .project-card, .card, .timeline li');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
      }
    });
  }, {threshold: 0.08});
  revealEls.forEach(el => {
    el.classList.add('pre-reveal');
    io.observe(el);
  });

  // Active nav link highlighting
  const sections = document.querySelectorAll('main section[id]');
  const navLinks = document.querySelectorAll('.nav-list a');

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      const id = entry.target.id;
      const link = document.querySelector(`.nav-list a[href="#${id}"]`);
      if (entry.isIntersecting) {
        navLinks.forEach(l => l.classList.remove('active'));
        if (link) link.classList.add('active');
      }
    });
  }, {rootMargin: '-40% 0px -40% 0px'}); // central area

  sections.forEach(s => sectionObserver.observe(s));
});